let niveles = [
  "Nivel 1: 1s^2",
  "Nivel 2: 2s^2 2p^6",
  "Nivel 3: 3s^2 3p^6 3d^10",
  "Nivel 4: 4s^2 4p^6 4d^10 4f^14",
  "Nivel 5: 5s^2 5p^6 5d^10 5f^14",
  "Nivel 6: 6s^2 6p^6 6d^10",
  "Nivel 7: 7s^2 7p^6"];

let cantidad = parseInt(prompt("¿Cuántos niveles quiere ver? (de 1 a 7):"));

if (cantidad >= 1 && cantidad <= 7) {
  console.log("Configuración electrónica hasta el nivel " + cantidad + ":");
  for (let i = 0; i < cantidad; i++) {
    console.log(niveles[i]);
  }
} else {
  console.log("Por favor ingrese el un número entre 1 y 7");
}

